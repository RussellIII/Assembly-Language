#include<stdio.h>
#include<string.h>

#define N 30
extern void ALTER(void);
extern void COUNT_RECOM(void);
extern void RANK_RECOM(void);
extern void LDISPLAY(void);
extern char GA1;



void func1(void) {
	char stuff[11];
	short *n;
	char *p=NULL;
	char *find=NULL;
	int i,j;
	printf("WHAT DO YOU WANT TO QUERY?\n");
	while (1){
		asm mov p,offset GA1;
		gets(stuff);
		for (j=0;j<30;j++){
			for (i=0;i<10;i++){
				if (stuff[i]!=*(p+i)){
					break;
				}
			}
			if (j==10){
				find=p;
				break;
			}
			else if(*(p+j)==0){
				find=p;
				break;
			}
		}
			if (find==NULL){
				printf("THINGS NOT FOUND! INPUT AGAIN.\n");
				continue;
			}
			else {
				printf("NAME:");
				printf("%s\n",stuff);
				printf("DISCOUNT:%d\n",*(find+10));
				n=(short *)(find+11) ;
				printf("PURCHASE_PRICE:%d\n",*n);
				printf("SALE_PRICE:%d\n",*(n+1));
				printf("PURCHASE_NUMBER:%d\n",*(n+2));
				printf("SALE_NUMBER:%d\n",*(n+3));
				printf("RECOMMENDATION:%d\n",*(n+4));
				break;
			}
		}
	}
	


int main() {

	
    int i=0;
	char bname[11] = "liuchenyan";                //��½��Ϣ
	char bpass[11] = "test";
	char inname[10];
	char inpass[10];
	int auth = 1;//��½״̬��0��ʾδ�¼��1��ʽ
	int choice;  //ѡ����
    
	while (1){
		auth = 1;
		printf(" ----------------------------------------------------------------------------- \n");
		printf("|                                    SHOP                                     |\n");
		printf(" ----------------------------------------------------------------------------- \n");
		printf("Please log in:\n");
		printf("name:\n");
		for (i = 0;i < 11;i++) {
			inname[i] = getchar();
			if (inname[i] == '\n') {
				inname[i] = '\0';
				break;
			}
		}
		if (inname[0] == '\0') {
			auth = 0;
		}
		if (auth != 0) {
			if (inname[0] == 'q'&&inname[1] == '\0') {
				break;
			}
			if (strcmp(bname, inname) != 0) {
				printf("WRONG NAME\n");
				continue;
			}
			printf("PASSWORD:\n");
			for (i = 0;i < 10;i++) {
				inpass[i] = getchar();
				if (inpass[i] == '\n') {
					inpass[i] = '\0';
					break;
				}
			}
			if ((strcmp(bpass, inpass)) != 0) {
				printf("WRONG PASSWORD\n");
				continue;
			}
		}
		//COUNT_RECOM();
		//RANK_RECOM();
		if (auth == 1) {
			while (1) {
				printf(" --------------------------------FUNCTION MENU-------------------------------\n");
				printf("|1. INQURE ITEM INFORMATION                         2. ALTER ITEM INFORMATION|\n");
				printf("|3. CALCULATE RECOMMENDATION                        4. RANK RECOMMENDATION   |\n");
				printf("|5. DISPLAY ALL ITEM INFORMATION                    6. QUIT                  |\n");
				printf(" ----------------------------------------------------------------------------\n");
				printf("PLEASSE ENTER THE NUMBER OF THE OPERATION YOU WANT CONDUCT:\n");
				scanf("%d",&choice) ;
				getchar();

				if (choice == 1) {
					func1();
					continue;
				}
				else if (choice == 2) {
					ALTER();
					continue;
				}
				else if (choice == 3) {
					COUNT_RECOM();
					continue;
				}
				else if (choice == 4) {
					RANK_RECOM();
				}
				else if (choice == 5) {
					LDISPLAY();
				}
				else {
					break;
				}
			}
		}
		else {
			while (1) {
				printf(" --------------------------------FUNCTION MENU--------------------------------\n");
				printf("|1. INQURE ITEM INFORMATION                           2. QUIT                 |\n");
				printf(" -----------------------------------------------------------------------------\n");
				printf("PLEASSE ENTER THE NUMBER OF THE OPERATION YOU WANT CONDUCT:\n");
				scanf("%d",&choice)   ;
				getchar();
				if (choice == 1) {
					func1();
					continue;
				}
				else {
					break;
				}
			}
		}
	}
	return 0;
}
